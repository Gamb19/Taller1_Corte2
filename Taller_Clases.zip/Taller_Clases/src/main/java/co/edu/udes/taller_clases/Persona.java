/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller_clases;

/**
 *
 * @author molin
 */
public class Persona {
     private double height;
    private String name;
  private int age;
 private float weight;
  private String nationality;
}
