/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller_clases;

/**
 *
 * @author molin
 */
public class Ciudad {
    private double area;
    private int population;
    private int houses;
    private String country;
}
